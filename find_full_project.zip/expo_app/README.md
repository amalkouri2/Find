# Expo app for Find

Run `npm install` then `npm start` using Expo CLI.
